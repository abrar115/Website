
export const state = {
  tracking: false,
  startXP: 0,
  lastXP: 0,
  startTime: 0,
  lastKnownXP: 0,
  gained: 0,
  seenInitialXP: false
}
